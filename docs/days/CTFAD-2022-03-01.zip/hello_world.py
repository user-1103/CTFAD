source = "VHdvIHByb3RvbnMgZXhwZWxsZWQgYXQgZWFjaCBjb3VwbGluZyBzaXRlIGNyZWF0ZXMgdGhlIG1vZGUgb2YgZm9yY2UsIHRoZSBlbWJyeW8gYmVjb21lcyBhIGZpc2ggdGhhdCB3ZSBkb24ndCBlbnRlciB1bnRpbCBhIHBsYXRlLCB3ZSdyZSBoZXJlIHRvIGV4cGVyaWVuY2UgZXZvbHZlIHRoZSBsaXR0bGUgdG9lLCBhdHJvcGh5LCBkb24ndCBhc2sgbWUgaG93IEknbGwgYmUgZGVhZCBpbiBhIHRob3VzYW5kIGxpZ2h0IHllYXJzLCB0aGFuayB5b3UsIHRoYW5rIHlvdS4gR2VuZXNpcyB0dXJucyB0byBpdHMgc291cmNlLCByZWR1Y3Rpb24gb2NjdXJzIHN0ZXB3aXNlIHRob3VnaCB0aGUgZXNzZW5jZSBpcyBhbGwgb25lLiBUaGUgRmxhZyBpczogQ1RGQUR7QG5kXyQwX0l0X0IzZ2luc30="

print(source[source.index("H")],
      source[source.index("e")],
      source[source.index("l")],
      source[source.index("l")],
      source[source.index("o")],
      " ",
      source[source.index("W")],
      source[source.index("o")],
      source[source.index("r")],
      source[source.index("l")],
      source[source.index("d")])
